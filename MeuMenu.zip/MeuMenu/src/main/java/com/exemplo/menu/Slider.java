package com.exemplo.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;

import java.util.Locale;
import java.util.function.Consumer;

/** Barra deslizante (tipo volume). */
public class Slider extends GuiButton {
    private final String label;
    private final float min, max, step;
    private final Consumer<Float> setter;
    private float norm;
    private boolean dragging;

    public Slider(int id, int x, int y, int w, int h, String label,
                  float min, float max, float step, float cur, Consumer<Float> setter) {
        super(id, x, y, w, h, "");
        this.label = label; this.min = min; this.max = max; this.step = step; this.setter = setter;
        this.norm = (cur - min) / (max - min);
        updateText();
    }

    private float value() {
        float v = min + norm * (max - min);
        v = Math.round(v / step) * step;
        return MathHelper.clamp_float(v, min, max);
    }

    private void updateText() {
        float v = value();
        String s = (v == (int) v) ? String.valueOf((int) v) : String.format(Locale.US, "%.1f", v);
        displayString = label + ": " + s;
    }

    private void applyMouse(int mx) {
        norm = MathHelper.clamp_float((float) (mx - (xPosition + 4)) / (float) (width - 8), 0f, 1f);
        setter.accept(value());
        updateText();
    }

    @Override
    protected int getHoverState(boolean mouseOver) { return 0; }

    @Override
    protected void mouseDragged(Minecraft mc, int mx, int my) {
        if (!visible) return;
        if (dragging) applyMouse(mx);
        mc.getTextureManager().bindTexture(buttonTextures);
        GlStateManager.color(1f, 1f, 1f, 1f);
        int hx = xPosition + (int) (norm * (width - 8));
        drawTexturedModalRect(hx, yPosition, 0, 66, 4, 20);
        drawTexturedModalRect(hx + 4, yPosition, 196, 66, 4, 20);
    }

    @Override
    public boolean mousePressed(Minecraft mc, int mx, int my) {
        if (super.mousePressed(mc, mx, my)) {
            dragging = true;
            applyMouse(mx);
            return true;
        }
        return false;
    }

    @Override
    public void mouseReleased(int mx, int my) { dragging = false; }
}
