package com.exemplo.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.MathHelper;

public class Aimbot {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void onFrame() {
        if (!Config.aimbot || mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) return;
        EntityLivingBase t = getTarget();
        if (t == null) return;
        EntityPlayerSP p = mc.thePlayer;
        float[] r = rotations(t);
        float yawDiff = MathHelper.wrapAngleTo180_float(r[0] - p.rotationYaw);
        float pitchDiff = r[1] - p.rotationPitch;
        float s = Math.max(1f, Config.aimSmooth);
        p.rotationYaw += yawDiff / s;
        p.rotationPitch = MathHelper.clamp_float(p.rotationPitch + pitchDiff / s, -90f, 90f);
    }

    private static EntityLivingBase getTarget() {
        EntityPlayerSP p = mc.thePlayer;
        EntityLivingBase best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.theWorld.loadedEntityList) {
            if (!(e instanceof EntityLivingBase) || e == p || e.isDead || e instanceof EntityArmorStand) continue;
            EntityLivingBase l = (EntityLivingBase) e;
            if (l.getHealth() <= 0) continue;
            boolean ok = Config.aimTarget == 2
                    || (Config.aimTarget == 0 && e instanceof EntityPlayer)
                    || (Config.aimTarget == 1 && e instanceof IMob);
            if (!ok) continue;
            double dist = p.getDistanceToEntity(e);
            if (dist > Config.aimRange) continue;
            if (!Config.aimWalls && !p.canEntityBeSeen(e)) continue;
            float[] r = rotations(l);
            float yd = Math.abs(MathHelper.wrapAngleTo180_float(r[0] - p.rotationYaw));
            float pd = Math.abs(r[1] - p.rotationPitch);
            if (Config.aimFov < 360f && yd > Config.aimFov / 2f) continue;
            double score = Config.aimPriority == 0 ? dist : yd + pd;
            if (score < bestScore) { bestScore = score; best = l; }
        }
        return best;
    }

    private static float[] rotations(Entity e) {
        EntityPlayerSP p = mc.thePlayer;
        double dx = e.posX - p.posX;
        double dy = (e.posY + e.height * 0.85) - (p.posY + p.getEyeHeight());
        double dz = e.posZ - p.posZ;
        double h = MathHelper.sqrt_double(dx * dx + dz * dz);
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitch = (float) -(Math.atan2(dy, h) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }
}
