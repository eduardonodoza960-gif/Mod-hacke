package com.exemplo.menu;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class MenuGui extends GuiScreen {
    private static int tab = 0;
    private static final String[] TABS = {"Aimbot", "ESP", "Extras"};
    private static final String[] TARGET = {"Jogadores", "Mobs", "Todos"};
    private static final String[] PRIO = {"Distância", "Mira"};
    private static final String[] PART = {"Cabeça", "Corpo", "Pés"};
    private static final String[] MODE = {"Normal", "Ninja", "Telly", "God (rápida)"};

    private int left, right, y0;

    private GuiButton btn(int id, int x, int row) { return new GuiButton(id, x, y0 + row * 24, 150, 20, ""); }

    @Override
    public void initGui() {
        buttonList.clear();
        left = width / 2 - 155;
        right = width / 2 + 5;
        int top = height / 2 - 100;
        y0 = top + 30;

        for (int i = 0; i < 3; i++) buttonList.add(new GuiButton(100 + i, left + i * 105, top, 100, 20, ""));

        if (tab == 0) {
            buttonList.add(btn(0, left, 0));
            buttonList.add(btn(1, left, 1));
            buttonList.add(btn(2, left, 2));
            buttonList.add(btn(3, left, 3));
            buttonList.add(btn(4, left, 4));
            buttonList.add(new Slider(10, right, y0, 150, 20, "FOV", 10, 360, 5, Config.aimFov, v -> Config.aimFov = v));
            buttonList.add(new Slider(11, right, y0 + 24, 150, 20, "Suavização", 1, 20, 1, Config.aimSmooth, v -> Config.aimSmooth = v));
            buttonList.add(new Slider(12, right, y0 + 48, 150, 20, "Alcance", 3, 8, 0.5f, Config.aimRange, v -> Config.aimRange = v));
            buttonList.add(btn(13, right, 3));
            buttonList.add(new Slider(14, right, y0 + 96, 150, 20, "CPS", 4, 20, 1, Config.cps, v -> Config.cps = v));
        } else if (tab == 1) {
            for (int i = 0; i < 6; i++) buttonList.add(btn(20 + i, left, i));
            for (int i = 0; i < 4; i++) buttonList.add(btn(26 + i, right, i));
        } else {
            buttonList.add(btn(30, left, 0));
            buttonList.add(btn(31, left, 1));
            buttonList.add(btn(32, left, 2));
        }
        refresh();
    }

    private String onOff(boolean b) { return b ? "§aON" : "§cOFF"; }

    /** Texto do botão (null para as barras, que cuidam do próprio texto). */
    private String label(int id) {
        switch (id) {
            case 100: case 101: case 102: {
                int t = id - 100;
                return (t == tab ? "§e§l" : "") + TABS[t];
            }
            case 0: return "Aimbot: " + onOff(Config.aimbot);
            case 1: return "Alvo: " + TARGET[Config.aimTarget];
            case 2: return "Prioridade: " + PRIO[Config.aimPriority];
            case 3: return "Mirar em: " + PART[Config.aimPart];
            case 4: return "Através de paredes: " + onOff(Config.aimWalls);
            case 13: return "Bater automático: " + onOff(Config.autoHit);
            case 20: return "ESP: " + onOff(Config.esp);
            case 21: return "Caixa 3D: " + onOff(Config.espBox);
            case 22: return "Caixa preenchida: " + onOff(Config.espFill);
            case 23: return "Tracers: " + onOff(Config.espTracers);
            case 24: return "Barra de vida: " + onOff(Config.espHealth);
            case 25: return "Nome/distância: " + onOff(Config.espNames);
            case 26: return "Jogadores: " + onOff(Config.espPlayers);
            case 27: return "Mobs: " + onOff(Config.espMobs);
            case 28: return "Itens: " + onOff(Config.espItems);
            case 29: return "Baús: " + onOff(Config.espChests);
            case 30: return "Ponte automática: " + onOff(Config.bridge);
            case 31: return "Modo: " + MODE[Config.bridgeMode];
            case 32: return "Anti-queda: " + onOff(Config.antiFall);
            default: return null;
        }
    }

    private void refresh() {
        for (Object o : buttonList) {
            GuiButton b = (GuiButton) o;
            String s = label(b.id);
            if (s != null) b.displayString = s;
        }
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id >= 100) { tab = b.id - 100; initGui(); return; }
        switch (b.id) {
            case 0: Config.aimbot = !Config.aimbot; break;
            case 1: Config.aimTarget = (Config.aimTarget + 1) % TARGET.length; break;
            case 2: Config.aimPriority = (Config.aimPriority + 1) % PRIO.length; break;
            case 3: Config.aimPart = (Config.aimPart + 1) % PART.length; break;
            case 4: Config.aimWalls = !Config.aimWalls; break;
            case 13: Config.autoHit = !Config.autoHit; break;
            case 20: Config.esp = !Config.esp; break;
            case 21: Config.espBox = !Config.espBox; break;
            case 22: Config.espFill = !Config.espFill; break;
            case 23: Config.espTracers = !Config.espTracers; break;
            case 24: Config.espHealth = !Config.espHealth; break;
            case 25: Config.espNames = !Config.espNames; break;
            case 26: Config.espPlayers = !Config.espPlayers; break;
            case 27: Config.espMobs = !Config.espMobs; break;
            case 28: Config.espItems = !Config.espItems; break;
            case 29: Config.espChests = !Config.espChests; break;
            case 30: Config.bridge = !Config.bridge; break;
            case 31: Config.bridgeMode = (Config.bridgeMode + 1) % MODE.length; break;
            case 32: Config.antiFall = !Config.antiFall; break;
        }
        refresh();
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_RSHIFT) { mc.displayGuiScreen(null); return; }
        super.keyTyped(c, key);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "§lMeuMenu §7- Right Shift fecha", width / 2, height / 2 - 118, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
        if (tab == 2) {
            int x = right, y = y0;
            drawString(fontRendererObj, "§eModos da ponte:", x, y, 0xFFFFFF);
            drawString(fontRendererObj, "§7Normal: põe bloco sob e à frente", x, y + 14, 0xFFFFFF);
            drawString(fontRendererObj, "§7Ninja: agacha na beirada e põe", x, y + 26, 0xFFFFFF);
            drawString(fontRendererObj, "§7Telly: pula andando e põe bloco", x, y + 38, 0xFFFFFF);
            drawString(fontRendererObj, "§7God: põe bloco mais longe (rápida)", x, y + 50, 0xFFFFFF);
            drawString(fontRendererObj, "§7Anti-queda: agacha sozinho na beirada", x, y + 70, 0xFFFFFF);
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
