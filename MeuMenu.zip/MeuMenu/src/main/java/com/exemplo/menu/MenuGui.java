package com.exemplo.menu;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class MenuGui extends GuiScreen {
    private static final float[] RANGE = {3f, 4.5f, 6f, 10f, 20f, 50f};
    private static final float[] FOV = {30f, 60f, 90f, 180f, 360f};
    private static final float[] SMOOTH = {1f, 3f, 5f, 10f, 20f};
    private static final String[] TARGET = {"Jogadores", "Mobs", "Todos"};
    private static final String[] PRIO = {"Distância", "Mira"};

    @Override
    public void initGui() {
        buttonList.clear();
        int lx = width / 2 - 155, rx = width / 2 + 5, y0 = height / 2 - 80;
        for (int i = 0; i < 7; i++) buttonList.add(new GuiButton(i, lx, y0 + i * 24, 150, 20, ""));
        for (int i = 0; i < 6; i++) buttonList.add(new GuiButton(10 + i, rx, y0 + i * 24, 150, 20, ""));
        refresh();
    }

    private String onOff(boolean b) { return b ? "§aON" : "§cOFF"; }

    private void refresh() {
        for (Object o : buttonList) {
            GuiButton b = (GuiButton) o;
            switch (b.id) {
                case 0: b.displayString = "Aimbot: " + onOff(Config.aimbot); break;
                case 1: b.displayString = "Alvo: " + TARGET[Config.aimTarget]; break;
                case 2: b.displayString = "Prioridade: " + PRIO[Config.aimPriority]; break;
                case 3: b.displayString = "Alcance: " + Config.aimRange; break;
                case 4: b.displayString = "FOV: " + (int) Config.aimFov; break;
                case 5: b.displayString = "Suavização: " + (int) Config.aimSmooth; break;
                case 6: b.displayString = "Através de paredes: " + onOff(Config.aimWalls); break;
                case 10: b.displayString = "ESP: " + onOff(Config.esp); break;
                case 11: b.displayString = "Caixas: " + onOff(Config.espBox); break;
                case 12: b.displayString = "Tracers: " + onOff(Config.espTracers); break;
                case 13: b.displayString = "Mobs: " + onOff(Config.espMobs); break;
                case 14: b.displayString = "Itens: " + onOff(Config.espItems); break;
                case 15: b.displayString = "Ponte automática: " + onOff(Config.bridge); break;
            }
        }
    }

    private float next(float[] arr, float cur) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == cur) return arr[(i + 1) % arr.length];
        return arr[0];
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        switch (b.id) {
            case 0: Config.aimbot = !Config.aimbot; break;
            case 1: Config.aimTarget = (Config.aimTarget + 1) % TARGET.length; break;
            case 2: Config.aimPriority = (Config.aimPriority + 1) % PRIO.length; break;
            case 3: Config.aimRange = next(RANGE, Config.aimRange); break;
            case 4: Config.aimFov = next(FOV, Config.aimFov); break;
            case 5: Config.aimSmooth = next(SMOOTH, Config.aimSmooth); break;
            case 6: Config.aimWalls = !Config.aimWalls; break;
            case 10: Config.esp = !Config.esp; break;
            case 11: Config.espBox = !Config.espBox; break;
            case 12: Config.espTracers = !Config.espTracers; break;
            case 13: Config.espMobs = !Config.espMobs; break;
            case 14: Config.espItems = !Config.espItems; break;
            case 15: Config.bridge = !Config.bridge; break;
        }
        refresh();
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_RSHIFT) { mc.displayGuiScreen(null); return; }
        super.keyTyped(c, key);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "§lMeuMenu §7- Right Shift para fechar", width / 2, height / 2 - 105, 0xFFFFFF);
        drawString(fontRendererObj, "§eAimbot", width / 2 - 155, height / 2 - 93, 0xFFFFFF);
        drawString(fontRendererObj, "§eESP / Ponte", width / 2 + 5, height / 2 - 93, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
