package com.exemplo.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = "meumenu", name = "MeuMenu", version = "1.0", acceptedMinecraftVersions = "[1.8.9]")
public class MeuMenu {
    private final Minecraft mc = Minecraft.getMinecraft();
    private final KeyBinding menuKey = new KeyBinding("Abrir menu", Keyboard.KEY_RSHIFT, "MeuMenu");

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(menuKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            AutoBridge.preTick();
            return;
        }
        if (menuKey.isPressed() && mc.currentScreen == null) mc.displayGuiScreen(new MenuGui());
        Aimbot.onTick();
        AutoBridge.onTick();
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) Aimbot.onFrame();
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent e) {
        Esp.render(e.partialTicks);
    }
}
