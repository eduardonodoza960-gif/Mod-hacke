package com.exemplo.menu;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

/**
 * Ponte automática: coloca blocos sob e à frente dos pés.
 * Anti-queda: agacha sozinho na beirada (não deixa cair).
 * Modos: 0 Normal, 1 Ninja (agacha na beirada), 2 Telly (pula andando), 3 God (coloca mais à frente).
 */
public class AutoBridge {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static boolean weSneak = false;

    /** Direção do movimento pelo que você está apertando (null se parado). */
    private static double[] dir(EntityPlayerSP p) {
        float f = p.movementInput.moveForward, s = p.movementInput.moveStrafe;
        if (f == 0f && s == 0f) return null;
        double yaw = Math.toRadians(p.rotationYaw);
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1e-4) return null;
        return new double[]{dx / len, dz / len};
    }

    private static boolean atEdge(EntityPlayerSP p) {
        if (!p.onGround) return false;
        double[] d = dir(p);
        if (d == null) return false;
        AxisAlignedBB bb = p.getEntityBoundingBox().offset(d[0] * 0.45, -0.6, d[1] * 0.45);
        return mc.theWorld.getCollidingBoundingBoxes(p, bb).isEmpty();
    }

    /** Antes do tick: agacha automaticamente na beirada. */
    public static void preTick() {
        EntityPlayerSP p = mc.thePlayer;
        if (p == null || mc.theWorld == null) return;
        int code = mc.gameSettings.keyBindSneak.getKeyCode();
        boolean useEdge = Config.antiFall || (Config.bridge && Config.bridgeMode == 1);
        if (useEdge && mc.currentScreen == null && atEdge(p)) {
            KeyBinding.setKeyBindState(code, true);
            weSneak = true;
        } else if (weSneak) {
            KeyBinding.setKeyBindState(code, Keyboard.isKeyDown(code));
            weSneak = false;
        }
    }

    /** Depois do tick: coloca os blocos. */
    public static void onTick() {
        if (!Config.bridge || mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) return;
        EntityPlayerSP p = mc.thePlayer;
        double[] d = dir(p);

        if (Config.bridgeMode == 2 && d != null && p.onGround && p.movementInput.moveForward > 0f) p.jump();

        int slot = findBlockSlot();
        if (slot == -1) return;

        double[] dists = Config.bridgeMode == 3 ? new double[]{0.9, 0.45, 0.0} : new double[]{0.0, 0.45};
        int y = MathHelper.floor_double(p.getEntityBoundingBox().minY + 0.001) - 1;

        int old = p.inventory.currentItem;
        p.inventory.currentItem = slot;
        for (double L : dists) {
            if (L > 0 && d == null) continue;
            double x = p.posX + (L > 0 ? d[0] * L : 0);
            double z = p.posZ + (L > 0 ? d[1] * L : 0);
            BlockPos target = new BlockPos(MathHelper.floor_double(x), y, MathHelper.floor_double(z));
            if (tryPlace(p, target)) break;
        }
        p.inventory.currentItem = old;
    }

    private static boolean tryPlace(EntityPlayerSP p, BlockPos target) {
        if (!mc.theWorld.isAirBlock(target)) return false;
        for (EnumFacing f : EnumFacing.values()) {
            BlockPos n = target.offset(f);
            if (mc.theWorld.isAirBlock(n) || mc.theWorld.getBlockState(n).getBlock().getMaterial().isLiquid()) continue;
            EnumFacing side = f.getOpposite();
            Vec3 hit = new Vec3(n.getX() + 0.5 + side.getFrontOffsetX() * 0.5,
                                n.getY() + 0.5 + side.getFrontOffsetY() * 0.5,
                                n.getZ() + 0.5 + side.getFrontOffsetZ() * 0.5);
            if (mc.playerController.onPlayerRightClick(p, mc.theWorld, p.getHeldItem(), n, side, hit)) {
                p.swingItem();
                return true;
            }
        }
        return false;
    }

    private static int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.thePlayer.inventory.getStackInSlot(i);
            if (s == null || s.stackSize <= 0 || !(s.getItem() instanceof ItemBlock)) continue;
            Block b = ((ItemBlock) s.getItem()).getBlock();
            if (b.isFullCube() && !(b instanceof BlockFalling) && !(b instanceof ITileEntityProvider)) return i;
        }
        return -1;
    }
}
