package com.exemplo.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/** Coloca blocos automaticamente embaixo dos pés (estilo scaffold). */
public class AutoBridge {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void onTick() {
        if (!Config.bridge || mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) return;
        EntityPlayerSP p = mc.thePlayer;

        BlockPos below = new BlockPos(MathHelper.floor_double(p.posX),
                MathHelper.floor_double(p.getEntityBoundingBox().minY) - 1,
                MathHelper.floor_double(p.posZ));
        if (!mc.theWorld.isAirBlock(below)) return;

        int slot = findBlockSlot();
        if (slot == -1) return;
        int old = p.inventory.currentItem;
        p.inventory.currentItem = slot;

        for (EnumFacing f : EnumFacing.values()) {
            BlockPos n = below.offset(f);
            if (mc.theWorld.isAirBlock(n) || mc.theWorld.getBlockState(n).getBlock().getMaterial().isLiquid()) continue;
            EnumFacing side = f.getOpposite();
            Vec3 hit = new Vec3(n.getX() + 0.5 + side.getFrontOffsetX() * 0.5,
                                n.getY() + 0.5 + side.getFrontOffsetY() * 0.5,
                                n.getZ() + 0.5 + side.getFrontOffsetZ() * 0.5);
            if (mc.playerController.onPlayerRightClick(p, mc.theWorld, p.getHeldItem(), n, side, hit)) {
                p.swingItem();
                break;
            }
        }
        p.inventory.currentItem = old;
    }

    private static int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.thePlayer.inventory.getStackInSlot(i);
            if (s != null && s.stackSize > 0 && s.getItem() instanceof ItemBlock
                    && ((ItemBlock) s.getItem()).getBlock().isFullCube()) return i;
        }
        return -1;
    }
}
