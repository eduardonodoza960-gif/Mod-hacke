package com.exemplo.menu;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

/**
 * Ponte automática.
 * - Anti-queda: agacha sozinho na beirada (inclusive nas esquinas) e põe bloco à frente.
 * - Rápida: vários blocos por tick e corre sozinho.
 * Modos: 0 Normal, 1 Ninja, 2 Telly (pula andando), 3 God (coloca mais longe).
 */
public class AutoBridge {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static boolean weSneak = false, weSprint = false;

    /** Direção pelo que você está apertando (null se parado). */
    private static double[] inputDir(EntityPlayerSP p) {
        float f = p.movementInput.moveForward, s = p.movementInput.moveStrafe;
        if (f == 0f && s == 0f) return null;
        double yaw = Math.toRadians(p.rotationYaw);
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        return len < 1e-4 ? null : new double[]{dx / len, dz / len};
    }

    /** Direção real em que você está indo (útil nas esquinas, quando a inércia leva pra outro lado). */
    private static double[] motionDir(EntityPlayerSP p) {
        double len = Math.sqrt(p.motionX * p.motionX + p.motionZ * p.motionZ);
        return len < 0.02 ? null : new double[]{p.motionX / len, p.motionZ / len};
    }

    private static boolean noGroundAhead(EntityPlayerSP p, double[] d) {
        if (d == null) return false;
        for (double dist : new double[]{0.35, 0.6}) {
            AxisAlignedBB bb = p.getEntityBoundingBox().offset(d[0] * dist, -0.6, d[1] * dist);
            if (mc.theWorld.getCollidingBoundingBoxes(p, bb).isEmpty()) return true;
        }
        return false;
    }

    private static boolean atEdge(EntityPlayerSP p) {
        if (!p.onGround) return false;
        return noGroundAhead(p, inputDir(p)) || noGroundAhead(p, motionDir(p));
    }

    /** Antes do tick: agacha na beirada e corre automaticamente. */
    public static void preTick() {
        EntityPlayerSP p = mc.thePlayer;
        if (p == null || mc.theWorld == null) return;

        int sneakKey = mc.gameSettings.keyBindSneak.getKeyCode();
        boolean useEdge = Config.antiFall || (Config.bridge && Config.bridgeMode == 1);
        boolean sneaking = false;
        if (useEdge && mc.currentScreen == null && atEdge(p)) {
            KeyBinding.setKeyBindState(sneakKey, true);
            weSneak = true;
            sneaking = true;
        } else if (weSneak) {
            KeyBinding.setKeyBindState(sneakKey, Keyboard.isKeyDown(sneakKey));
            weSneak = false;
        }

        int sprintKey = mc.gameSettings.keyBindSprint.getKeyCode();
        boolean fwd = mc.gameSettings.keyBindForward.isKeyDown();
        if (Config.bridge && Config.bridgeSprint && fwd && !sneaking && mc.currentScreen == null) {
            KeyBinding.setKeyBindState(sprintKey, true);
            weSprint = true;
        } else if (weSprint) {
            KeyBinding.setKeyBindState(sprintKey, Keyboard.isKeyDown(sprintKey));
            weSprint = false;
        }
    }

    /** Depois do tick: coloca os blocos. */
    public static void onTick() {
        if (!Config.bridge || mc.thePlayer == null || mc.theWorld == null || mc.currentScreen != null) return;
        EntityPlayerSP p = mc.thePlayer;
        double[] d = inputDir(p);
        if (d == null) d = motionDir(p);

        if (Config.bridgeMode == 2 && p.onGround && p.movementInput.moveForward > 0f) p.jump();

        double[] dists = Config.bridgeMode == 3
                ? new double[]{0.0, 0.45, 0.9, 1.35, 1.8}
                : new double[]{0.0, 0.45, 0.9, 1.35};
        int max = (int) Config.bridgeSpeed + (Config.bridgeMode == 3 ? 1 : 0);
        int y = MathHelper.floor_double(p.getEntityBoundingBox().minY + 0.001) - 1;

        int placed = 0;
        for (double L : dists) {
            if (placed >= max) break;
            if (L > 0 && d == null) continue;
            double x = p.posX + (L > 0 ? d[0] * L : 0);
            double z = p.posZ + (L > 0 ? d[1] * L : 0);
            BlockPos target = new BlockPos(MathHelper.floor_double(x), y, MathHelper.floor_double(z));
            if (!mc.theWorld.isAirBlock(target)) continue;
            if (!ensureBlockInHand(p)) break;
            if (tryPlace(p, target)) placed++;
        }
    }

    /** Só troca de slot se o item na mão NÃO for um bloco bom (evita o "bloco bugado" de ficar trocando). */
    private static boolean ensureBlockInHand(EntityPlayerSP p) {
        if (isGoodBlock(p.getHeldItem())) return true;
        for (int i = 0; i < 9; i++) {
            if (isGoodBlock(p.inventory.getStackInSlot(i))) {
                p.inventory.currentItem = i;
                return true;
            }
        }
        return false;
    }

    private static boolean isGoodBlock(ItemStack s) {
        if (s == null || s.stackSize <= 0 || !(s.getItem() instanceof ItemBlock)) return false;
        Block b = ((ItemBlock) s.getItem()).getBlock();
        return b.isFullCube() && !(b instanceof BlockFalling) && !(b instanceof ITileEntityProvider);
    }

    private static boolean tryPlace(EntityPlayerSP p, BlockPos target) {
        for (EnumFacing f : EnumFacing.values()) {
            BlockPos n = target.offset(f);
            if (mc.theWorld.isAirBlock(n) || mc.theWorld.getBlockState(n).getBlock().getMaterial().isLiquid()) continue;
            EnumFacing side = f.getOpposite();
            Vec3 hit = new Vec3(n.getX() + 0.5 + side.getFrontOffsetX() * 0.5,
                                n.getY() + 0.5 + side.getFrontOffsetY() * 0.5,
                                n.getZ() + 0.5 + side.getFrontOffsetZ() * 0.5);
            if (mc.playerController.onPlayerRightClick(p, mc.theWorld, p.getHeldItem(), n, side, hit)) {
                p.swingItem();
                return true;
            }
        }
        return false;
    }
}
