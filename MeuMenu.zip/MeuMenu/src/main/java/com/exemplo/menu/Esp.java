package com.exemplo.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

public class Esp {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void render(float pt) {
        if (!Config.esp || mc.theWorld == null || mc.thePlayer == null) return;

        double vx = mc.getRenderManager().viewerPosX;
        double vy = mc.getRenderManager().viewerPosY;
        double vz = mc.getRenderManager().viewerPosZ;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glLineWidth(1.8f);

        Vec3 look = mc.thePlayer.getLook(pt);

        for (Entity e : mc.theWorld.loadedEntityList) {
            if (e == mc.thePlayer || e.isDead) continue;
            float[] c;
            if (e instanceof EntityPlayer) c = new float[]{1f, 0.2f, 0.2f};
            else if (e instanceof EntityArmorStand) continue;
            else if (e instanceof EntityLivingBase && Config.espMobs) c = new float[]{1f, 0.6f, 0.1f};
            else if (e instanceof EntityItem && Config.espItems) c = new float[]{0.2f, 0.9f, 1f};
            else continue;

            double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - vx;
            double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - vy;
            double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - vz;

            if (Config.espBox) {
                AxisAlignedBB b = e.getEntityBoundingBox();
                double dx = x - (e.posX - vx), dy = y - (e.posY - vy), dz = z - (e.posZ - vz);
                AxisAlignedBB r = new AxisAlignedBB(b.minX - vx + dx, b.minY - vy + dy, b.minZ - vz + dz,
                        b.maxX - vx + dx, b.maxY - vy + dy, b.maxZ - vz + dz);
                RenderGlobal.drawOutlinedBoundingBox(r, (int) (c[0] * 255), (int) (c[1] * 255), (int) (c[2] * 255), 255);
            }

            if (Config.espTracers) {
                GL11.glColor4f(c[0], c[1], c[2], 1f);
                Tessellator t = Tessellator.getInstance();
                WorldRenderer wr = t.getWorldRenderer();
                wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION);
                wr.pos(look.xCoord, look.yCoord, look.zCoord).endVertex();
                wr.pos(x, y + e.height / 2.0, z).endVertex();
                t.draw();
            }
        }

        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }
}
