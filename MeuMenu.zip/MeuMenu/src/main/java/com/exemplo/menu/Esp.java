package com.exemplo.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class Esp {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private static float[] colorFor(Entity e) {
        if (e instanceof EntityArmorStand) return null;
        if (e instanceof EntityPlayer) return Config.espPlayers ? new float[]{1f, 0.2f, 0.2f} : null;
        if (e instanceof EntityLivingBase) return Config.espMobs ? new float[]{1f, 0.6f, 0.1f} : null;
        if (e instanceof EntityItem) return Config.espItems ? new float[]{0.2f, 0.9f, 1f} : null;
        return null;
    }

    public static void render(float pt) {
        if (!Config.esp || mc.theWorld == null || mc.thePlayer == null) return;

        RenderManager rm = mc.getRenderManager();
        double vx = rm.viewerPosX, vy = rm.viewerPosY, vz = rm.viewerPosZ;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glLineWidth(1.8f);

        Vec3 look = mc.thePlayer.getLook(pt);
        List<double[]> labels = new ArrayList<double[]>();
        List<EntityLivingBase> labelEnt = new ArrayList<EntityLivingBase>();

        for (Entity e : mc.theWorld.loadedEntityList) {
            if (e == mc.thePlayer || e.isDead) continue;
            float[] c = colorFor(e);
            if (c == null) continue;

            double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * pt - vx;
            double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * pt - vy;
            double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt - vz;

            AxisAlignedBB b = e.getEntityBoundingBox();
            double dx = x - (e.posX - vx), dy = y - (e.posY - vy), dz = z - (e.posZ - vz);
            AxisAlignedBB r = new AxisAlignedBB(b.minX - vx + dx, b.minY - vy + dy, b.minZ - vz + dz,
                    b.maxX - vx + dx, b.maxY - vy + dy, b.maxZ - vz + dz);

            if (Config.espFill) fill(r, c[0], c[1], c[2], 0.18f);
            if (Config.espBox) {
                RenderGlobal.drawOutlinedBoundingBox(r, (int) (c[0] * 255), (int) (c[1] * 255), (int) (c[2] * 255), 255);
            }
            if (Config.espTracers) {
                GL11.glColor4f(c[0], c[1], c[2], 1f);
                Tessellator t = Tessellator.getInstance();
                WorldRenderer wr = t.getWorldRenderer();
                wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION);
                wr.pos(look.xCoord, look.yCoord, look.zCoord).endVertex();
                wr.pos(x, y + e.height / 2.0, z).endVertex();
                t.draw();
            }
            if (e instanceof EntityLivingBase && (Config.espHealth || Config.espNames)) {
                labels.add(new double[]{x, y + e.height + 0.4, z});
                labelEnt.add((EntityLivingBase) e);
            }
        }

        if (Config.espChests) {
            for (TileEntity te : mc.theWorld.loadedTileEntityList) {
                if (!(te instanceof TileEntityChest || te instanceof TileEntityEnderChest)) continue;
                BlockPos bp = te.getPos();
                if (mc.thePlayer.getDistanceSq(bp) > 128 * 128) continue;
                AxisAlignedBB r = new AxisAlignedBB(bp.getX() - vx, bp.getY() - vy, bp.getZ() - vz,
                        bp.getX() + 1 - vx, bp.getY() + 1 - vy, bp.getZ() + 1 - vz);
                if (Config.espFill) fill(r, 1f, 0.85f, 0.1f, 0.18f);
                RenderGlobal.drawOutlinedBoundingBox(r, 255, 217, 25, 255);
            }
        }

        // Nomes e barra de vida (sempre virados para a câmera)
        FontRenderer fr = mc.fontRendererObj;
        for (int i = 0; i < labels.size(); i++) {
            double[] pos = labels.get(i);
            EntityLivingBase le = labelEnt.get(i);
            double dist = Math.sqrt(pos[0] * pos[0] + pos[1] * pos[1] + pos[2] * pos[2]);
            float s = (float) Math.max(0.025, dist * 0.0065);

            GlStateManager.pushMatrix();
            GlStateManager.translate(pos[0], pos[1], pos[2]);
            GL11.glNormal3f(0f, 1f, 0f);
            GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
            GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
            GlStateManager.scale(-s, -s, s);

            if (Config.espHealth) {
                float frac = Math.max(0f, Math.min(1f, le.getHealth() / Math.max(1f, le.getMaxHealth())));
                quad(-20, 11, 20, 15, 0f, 0f, 0f, 0.75f);
                quad(-20, 11, -20 + 40 * frac, 15, 1f - frac, frac, 0.1f, 1f);
            }
            if (Config.espNames) {
                GlStateManager.enableTexture2D();
                String txt = le.getName() + " " + (int) le.getDistanceToEntity(mc.thePlayer) + "m";
                int w = fr.getStringWidth(txt);
                fr.drawStringWithShadow(txt, -w / 2f, 0f, 0xFFFFFFFF);
                GlStateManager.disableTexture2D();
            }
            GlStateManager.popMatrix();
        }

        GlStateManager.enableTexture2D();
        GlStateManager.enableCull();
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.popMatrix();
    }

    private static void quad(double x1, double y1, double x2, double y2, float r, float g, float b, float a) {
        GL11.glColor4f(r, g, b, a);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer w = t.getWorldRenderer();
        w.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION);
        w.pos(x1, y2, 0).endVertex();
        w.pos(x2, y2, 0).endVertex();
        w.pos(x2, y1, 0).endVertex();
        w.pos(x1, y1, 0).endVertex();
        t.draw();
    }

    private static void v(WorldRenderer w, double x, double y, double z) { w.pos(x, y, z).endVertex(); }

    private static void fill(AxisAlignedBB b, float r, float g, float bl, float a) {
        GL11.glColor4f(r, g, bl, a);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer w = t.getWorldRenderer();
        w.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION);
        v(w, b.minX, b.minY, b.minZ); v(w, b.maxX, b.minY, b.minZ); v(w, b.maxX, b.minY, b.maxZ); v(w, b.minX, b.minY, b.maxZ);
        v(w, b.minX, b.maxY, b.minZ); v(w, b.maxX, b.maxY, b.minZ); v(w, b.maxX, b.maxY, b.maxZ); v(w, b.minX, b.maxY, b.maxZ);
        v(w, b.minX, b.minY, b.minZ); v(w, b.maxX, b.minY, b.minZ); v(w, b.maxX, b.maxY, b.minZ); v(w, b.minX, b.maxY, b.minZ);
        v(w, b.minX, b.minY, b.maxZ); v(w, b.maxX, b.minY, b.maxZ); v(w, b.maxX, b.maxY, b.maxZ); v(w, b.minX, b.maxY, b.maxZ);
        v(w, b.minX, b.minY, b.minZ); v(w, b.minX, b.minY, b.maxZ); v(w, b.minX, b.maxY, b.maxZ); v(w, b.minX, b.maxY, b.minZ);
        v(w, b.maxX, b.minY, b.minZ); v(w, b.maxX, b.minY, b.maxZ); v(w, b.maxX, b.maxY, b.maxZ); v(w, b.maxX, b.maxY, b.minZ);
        t.draw();
    }
}
