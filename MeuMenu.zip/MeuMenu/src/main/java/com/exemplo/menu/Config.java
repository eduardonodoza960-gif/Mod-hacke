package com.exemplo.menu;

public class Config {
    // Módulos
    public static boolean aimbot, esp, bridge;

    // Aimbot
    public static int aimTarget = 0;     // 0 jogadores, 1 mobs, 2 todos
    public static int aimPriority = 0;   // 0 mais perto, 1 mais perto da mira
    public static float aimRange = 4.5f;
    public static float aimFov = 90f;    // 360 = sem limite
    public static float aimSmooth = 5f;  // 1 = instantâneo
    public static boolean aimWalls = false;

    // ESP
    public static boolean espBox = true, espTracers = false, espMobs = false, espItems = false;
}
