package com.exemplo.menu;

public class Config {
    // Módulos
    public static boolean aimbot, esp, bridge, autoHit;
    public static boolean antiFall = true;

    // Aimbot
    public static int aimTarget = 0;     // 0 jogadores, 1 mobs, 2 todos
    public static int aimPriority = 0;   // 0 mais perto, 1 mais perto da mira
    public static int aimPart = 1;       // 0 cabeça, 1 corpo, 2 pés
    public static float aimRange = 4.5f; // até 8
    public static float aimFov = 90f;    // 360 = sem limite
    public static float aimSmooth = 5f;  // 1 = instantâneo
    public static float cps = 10f;       // cliques por segundo do auto-bater
    public static boolean aimWalls = false;

    // ESP
    public static boolean espBox = true, espFill = false, espTracers = false,
            espHealth = true, espNames = true,
            espPlayers = true, espMobs = false, espItems = false, espChests = false;

    // Ponte: 0 normal, 1 ninja, 2 telly, 3 god (rápida)
    public static int bridgeMode = 0;
    public static float bridgeSpeed = 2f;      // blocos por tick (1 a 4)
    public static boolean bridgeSprint = true; // corre sozinho na ponte
}
